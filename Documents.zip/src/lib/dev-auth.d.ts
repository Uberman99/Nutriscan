export declare const isDevAuth: () => boolean;
export declare const getDevUser: () => {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  isSignedIn: boolean;
};
